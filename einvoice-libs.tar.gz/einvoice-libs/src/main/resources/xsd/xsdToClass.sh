#!/bin/sh

export LANGUAGE=en_US
export LANG=en_US.UTF-8

xjc -disableXmlSecurity -no-header -extension  -d $1 -b bindings.xjb CFEType.xsd
